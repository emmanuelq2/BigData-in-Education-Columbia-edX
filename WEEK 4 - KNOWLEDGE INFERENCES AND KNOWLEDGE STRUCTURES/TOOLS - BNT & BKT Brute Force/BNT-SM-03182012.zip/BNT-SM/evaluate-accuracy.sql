
/* evaluate baseline, ASR confidence, and posterior Pcorrect on first attempts */
# describe
select count(*) as num_words, 
count(distinct word), min(word), max(word),
knowledge = 0,
trn_correct, 
pow(2,floor(log2(s.total))) as bin,
avg(asr_accept = 2) as acceptance_rate,
avg(asr_accept = 1) as rejection_rate,
avg(confidence > .02), avg(correct > .02),
avg(confidence > .05), avg(correct > .05),
avg(confidence > .10), avg(correct > .10),
avg(confidence > .20), avg(correct > .20),
avg(confidence > .30), avg(correct > .30),
avg(confidence > .40), avg(correct > .40),
avg(confidence > .50), avg(correct > .50),
avg(confidence > .60), avg(correct > .60),
avg(confidence > .70), avg(correct > .70),
avg(confidence > .80), avg(correct > .80),
avg(confidence > .90), avg(correct > .90)
from now, training_data_word_stat s
where now.target_word = s.word
and trn_correct != 0
group by knowledge=0, trn_correct, bin 
